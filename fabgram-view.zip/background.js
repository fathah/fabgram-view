

function fetchData(){
    // fetch('http://ip-api.com/json').then(function(response) {
    //     console.log(response.json());
    // })
}


fetchData();